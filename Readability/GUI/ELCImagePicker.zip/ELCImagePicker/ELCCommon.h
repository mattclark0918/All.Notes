
#import <Foundation/Foundation.h>

#define kELCBarTintColor [UIColor colorWithRed:0x5E/255.0 green:0x7D/255.0 blue:0x9A/255.0 alpha:1.0]


